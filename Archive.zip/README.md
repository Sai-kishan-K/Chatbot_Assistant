# ocr-llm-mvp
MVP: OCR → Text Cleaning → LLM Analysis → Structured JSON Output
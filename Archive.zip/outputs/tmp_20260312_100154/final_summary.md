This document outlines the core functionalities of the Craft AI MLOps Platform, covering data storage, LLM model access, pipeline execution monitoring, pre-configured AI assistants, and resource tracking.

---

### **1. Data Management**

The platform provides a **Data store** (Cloud bucket) for managing files and execution results within your MLOps environments.

**1.1. Accessing and Navigating the Data Store:**
*   **Location:** Navigate to the "Data store" tab.
*   **View:** See a list of environments within your current project, showing space occupied, last update, and environment tags.
*   **Navigation:** Click an environment to view its tree-like file and folder structure. Navigate folders by clicking names; the current path is displayed above the tree for easy backtracking.

**1.2. File and Folder Actions:**
*   **Upload:** Manually add files to the Data store.
*   **Download:** Retrieve files (e.g., execution results) to your local computer.
*   **Create a new folder:** Add a new folder within the current view.
*   **Copy:** Select a file/folder via its checkbox or "..." menu, then use "Copy to" to choose a destination (can create new folders during this process).
*   **Delete:** Select a file/folder via its checkbox or "..." menu and click "Delete." **Caution:** Deletion is permanent and the platform does not detect critical file dependencies.
*   **Rename:** Use the "..." menu to rename any file or folder.

**1.3. Vector Database Integration:**
*   **Weaviate:** The platform supports Weaviate, a Vector Database, which can be provisioned simultaneously with your environment to facilitate LLM features like Retrieval Augmented Generation (RAG).

---

### **2. Generative AI Models (LLMs)**

The platform provides access to a selection of pre-configured Large Language Models (LLMs), each optimized for different use cases:

*   **GPT-5.2:**
    *   **Context Window:** 400k tokens (272k input / 128k output).
    *   **Use Cases:** Complex reasoning, programming, agent/tool orchestration, long document analysis, professional workflows.
*   **Mistral Large 3:**
    *   **Context Window:** ≈256k tokens.
    *   **Use Cases:** Enterprise applications, strong reasoning, large document handling, cost-effective RAG systems, business assistants.
*   **Mistral Small:**
    *   **Context Window:** ≈128k tokens.
    *   **Use Cases:** Speed and cost-optimized, conversational assistants, high-volume applications, low-latency requirements.
*   **GPT-5 mini:**
    *   **Context Window:** 400k tokens (272k input / 128k output).
    *   **Use Cases:** Cost/performance optimized for conversational AI, large-scale applications, latency/cost-sensitive agents.
*   **Qwen3 235B:**
    *   **Context Window:** ≈128k tokens.
    *   **Use Cases:** Open-weights model for reasoning, mathematics, programming, multilingual capabilities, advanced agents.
*   **GPT-oss 120B:**
    *   **Context Window:** ≈128k tokens.
    *   **Use Cases:** Open-weights model for sovereign/self-hosted deployments, balancing power, cost, and infrastructure control; suitable for internal assistants and enterprise RAG.

---

### **3. Pipeline Execution Monitoring**

This section details how to track, monitor, and analyze machine learning pipeline executions.

**3.1. Finding and Accessing Execution Details:**
*   **Location:** "Execution > Execution Tracking" page (select project first).
*   **Filtering:** Select an environment from the top-left selector to view pipelines or deployments with associated runs. You can also click an environment directly.
*   **SDK Access:** Use `sdk.get_pipeline_execution(execution_id)` to retrieve execution information.

**3.2. Reviewing Execution Information:**
*   **Inputs and Outputs:**
    *   **UI:** Navigate to the "Inputs/Outputs" tab. View Name, Type, Source/Destination Type, and Value.
    *   **SDK:** `sdk.get_pipeline_execution_input(execution_id, input_name)` and `sdk.get_pipeline_execution_output(execution_id, output_name)`.
*   **Metrics:**
    *   **UI:** In the "Metrics" tab, view simple metrics in a table and list metrics as graphs. Refresh the page to see updates.
    *   **SDK:** `sdk.get_metrics(name, pipeline_name, deployment_name, execution_id)` and `sdk.get_list_metrics(name, pipeline_name, deployment_name, execution_id)`.
*   **Logs:**
    *   **UI:** Access execution logs in the dedicated "Logs" tab. Refresh for updates.
    *   **SDK:** `sdk.get_pipeline_execution_logs(execution_id, from_datetime, to_datetime, limit)`.

**3.3. Comparing Multiple Executions:**
*   **Location:** "Executions > Execution Comparison" page.
*   **Table Comparison:**
    *   Select the desired environment.
    *   **Customize Display:** Use selectors to show/hide metadata, inputs, simple metrics, and list metrics columns.
    *   **Filter:** Use the "Filters" button or directly filter pipeline names in the table header.
    *   **Sort:** Click column headers to sort by values (e.g., accuracy). For list metrics, select a calculation mode (e.g., 'last', 'average') before sorting.
*   **List Metrics Visualization:**
    *   Select specific executions using the "eye" icon next to list metrics.
    *   Navigate to the "Visualize" tab (top right).
    *   View graphs comparing the evolution of selected list metrics across executions. Hide specific executions by clicking their names in the legend.

**3.4. Production Pipeline Monitoring:**
*   **Location:** "Monitoring > Pipeline metrics".
*   **Functionality:** Track the evolution of single metrics over time for any selected deployment, providing insight into model performance in production.

---

### **4. Pre-installed AI Assistants**

Craft AI provides several pre-configured AI assistants to accelerate onboarding and common tasks:

*   **Document Search (RAG):** Enhances LLM responses using documents stored by the administrator in the Data Store.
*   **Internet Search:** Enriches LLM responses by fetching information directly from the internet, displaying source URLs.
*   **Document Summarization:** Accurately summarizes documents by identifying key ideas and structuring them clearly, without adding external information.
*   **Spell Checker:** Detects and corrects spelling and grammar errors, preserving original style and vocabulary.
*   **Text Rephrasing:** Improves and reformulates texts into a desired style (formal, academic, journalistic, etc.), enriching vocabulary while maintaining original meaning.
*   **Drafting Assistance:** Helps draft and refine administrative documents (letters, notes, reports) in a formal, clear, and compliant style.

---

### **5. Resource Monitoring**

Monitor the health and infrastructure usage of your environments.

**5.1. Accessing Resource Metrics:**
*   **Location:** "Monitoring > Resource metrics" page.
*   **Functionality:**
    *   View resource overuse indicators (cards at the top).
    *   Graphs display resource evolution (e.g., CPU, RAM) over time for selected environments.
    *   Individual worker curves and a cumulative curve for all workers are available.
    *   Download displayed data in `.csv` format, filtered by date and worker.
*   **SDK Access:** Use `sdk.get_resource_metrics(start_date, end_date, csv)` to retrieve resource data (boolean `csv` parameter returns data as bytes in CSV format).
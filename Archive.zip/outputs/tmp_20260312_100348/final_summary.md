This guide outlines the technical functionalities of the Craft AI MLOps Platform for managing machine learning pipelines, integrating with Git, utilizing a Vector Database, and leveraging Large Language Models.

---

### Craft AI MLOps Platform: Technical Guide

#### 1. Platform Overview

The Craft AI platform facilitates the creation, deployment, and management of AI applications at scale. It supports both traditional Machine Learning models and secure AI agents powered by Large Language Models (LLMs).

**Key Capabilities:**
*   **End-to-end MLOps:** Manage the entire lifecycle of models.
*   **Infrastructure Automation:** Streamlined setup and deployment.
*   **Cloud Agnostic:** Deploy on various cloud providers.
*   **Scalability:** Easily scale applications.
*   **LLM Management:** Self-host and fine-tune LLMs.
*   **Comprehensive Monitoring:** Ensure optimal production use.
*   **Cost & Carbon Management:** Track and optimize AI resource usage.
*   **Regulatory Compliance:** Adhere to standards like GDPR and AI Act.

#### 2. Pipeline & Execution Management

Effectively track, monitor, and analyze the executions of your machine learning models.

**2.1. Execution Tracking & Details**
*   **Finding Executions:**
    *   **UI:** Navigate to `Execution > Execution Tracking`. Select a project, then an environment. Choose a pipeline or deployment to list its executions.
    *   **SDK:** Use `sdk.get_pipeline_execution(execution_id)` to retrieve general execution information.
    *   **Note:** Deleting a pipeline or deployment will also delete all associated executions.
*   **Viewing Inputs/Outputs:**
    *   **UI:** In the execution details, access the "Inputs/Outputs" tab. This displays a table with Name, Type, Source/Destination Type, and Source/Destination Value.
    *   **SDK:**
        *   `sdk.get_pipeline_execution(execution_id)` for general I/O overview.
        *   `sdk.get_pipeline_execution_input(execution_id, input_name)` for specific input details.
        *   `sdk.get_pipeline_execution_output(execution_id, output_name)` for specific output details.
*   **Accessing Metrics & Logs:**
    *   **UI:**
        *   **Metrics:** Go to the "Metrics" tab. Simple metrics are shown in a table, while list metrics (e.g., loss/accuracy over epochs) are visualized with graphs.
        *   **Logs:** Access the "Logs" tab. Use the refresh buttons to update displayed logs.
    *   **SDK:**
        *   `sdk.get_metrics(name, pipeline_name, deployment_name, execution_id)` for simple metrics.
        *   `sdk.get_list_metrics(name, pipeline_name, deployment_name, execution_id)` for list metrics.
        *   `sdk.get_pipeline_execution_logs(execution_id, from_datetime, to_datetime, limit)` for logs.

**2.2. Comparing Multiple Executions**
*   **Execution Comparison Table:**
    *   **UI:** Go to `Executions > Execution Comparison`. Select an environment.
    *   **Features:** The central table lists executions (rows) and their attributes (columns).
        *   Use **selectors** to choose which information (meta-data, inputs, simple metrics, list metrics, outputs) to display as columns.
        *   Use the **Filters button** to refine the execution list (e.g., by pipeline name).
        *   **Sort** columns by clicking on their headers. For list metrics, select the calculation mode (e.g., `last`, `average`, `min`) before sorting.
*   **Visualizing List Metrics:**
    *   **UI:** From the comparison table, select specific executions for visualization using the "eye" icon on the left of each row (only available for executions with list metrics). Then, navigate to the "visualize" tab (top right).
    *   This displays graphs comparing the evolution of list metrics across the selected executions. You can hide specific executions by clicking their names in the legend.

**2.3. Production Pipeline Monitoring**
*   **UI:** Access `Monitoring > Pipeline metrics` to observe the evolution of single metrics over time for a selected deployment, providing a global view of model performance in production.

#### 3. Git Repository Integration

Integrate your project with Git repositories for robust versioning, collaborative development, and production readiness.

**3.1. SSH Key Generation**
*   **Purpose:** Establish a secure SSH connection for the platform to access your Git repository. This requires a public/private RSA key pair.
*   **Warning:** The private key must be kept secure, *never* shared, and *never* stored in the platform's data store.
*   **Commands:**
    *   **Linux / MacOS:**
        ```bash
        ssh-keygen -m PEM -t rsa -b 4096 -f my-key-filename -q -N "" -C ""
        ```
        This generates `my-key-filename` (private key) and `my-key-filename.pub` (public key).
    *   **Windows:**
        1.  Ensure OpenSSH is installed (`Settings > Apps & features > Optional features`).
        2.  Run Command Prompt as Administrator.
        3.  Execute: `ssh-keygen`
        4.  Follow prompts; keys are saved by default to `C:\Users\your_username\.ssh\id_rsa` (private) and `id_rsa.pub` (public). Leave passphrase blank to bypass it.

**3.2. Adding Public Key to Git Host**
*   The `*.pub` (public) key must be added to your Git repository's deployment keys.
    *   **GitHub:**
        1.  Navigate to your repository's homepage.
        2.  Go to `Settings > Deploy Keys`.
        3.  Click `Add deploy key`.
        4.  Provide a name and paste the *full content* of `my-key-filename.pub`.
        5.  Do **not** enable "Allow write access".
        6.  Click "Add key".
    *   **GitLab:**
        1.  Navigate to your repository's homepage.
        2.  Go to `Settings > Repository`.
        3.  Expand the "Deploy keys" section.
        4.  Provide a name and paste the *full content* of `my-key-filename.pub`.
        5.  Do **not** enable "Grant write permissions to this key".
        6.  Click "Add key".

**3.3. Configuring Git in Craft AI (using Private Key)**
There are two methods to integrate the private key and repository information into the Craft AI platform:

*   **Method 1: Project-Level Integration (Default for Project Pipelines)**
    *   **UI:** Go to your project's settings page.
    *   **Parameters:**
        *   `Repository URL`: Enter the SSH URL of your repository (starts with `git@`).
        *   `Deploy key`: Paste the *full content* of your private SSH key (`my-key-filename`), including `-----BEGIN RSA PRIVATE KEY-----` and `-----END RSA PRIVATE KEY-----` tags.
        *   `Default branch`: Specify the default Git branch for the project.
    *   **SDK Implications:** Once configured, pipelines created via `sdk.create_pipeline(...)` in this project will default to using this Git repository.
*   **Method 2: Pipeline-Specific Integration (Overrides Project Settings)**
    *   You can specify Git configuration directly when creating a pipeline via the SDK. This will override any project-level settings.
    *   **SDK Example:**
        ```python
        import os
        from craft_ai_sdk import CraftAiSdk

        # Assume SDK initialization and private_key_value loaded
        # For example, from a file:
        with open('keys/my-key-filename', 'r') as file:
            private_key_value = file.read().rstrip()

        sdk.create_pipeline(
            function_path="src/my-source-code.py",
            function_name="my-function-name",
            pipeline_name="my-pipeline-name",
            container_config={
                "repository_url": "git@github.com:my-account/my-git-repo.git",
                "repository_deploy_key": private_key_value,
                "repository_branch": "main"
            }
        )
        ```

#### 4. Vector Database (Weaviate) Usage

The platform provides a Weaviate database for LLM-related tasks within your pipelines.

**4.1. Weaviate Deployment**
*   **Requirement:** Weaviate must be specified during **environment creation**. It cannot be added to an existing environment.
*   **Configuration:** Select the Weaviate option in the "Environment Creation" form. It will run in a dedicated pod with CPU processing.

**4.2. Accessing Weaviate from SDK**
*   To interact with Weaviate from your pipeline code:
    ```python
    import os
    from craft_ai_sdk import CraftAiSdk
    from dotenv import load_dotenv

    load_dotenv() # Load environment variables, e.g., SDK token
    sdk = CraftAiSdk(
        sdk_token=os.getenv("CRAFT_AI_SDK_TOKEN"), # Ensure token is set
        environment_url=os.getenv("CRAFT_AI_ENVIRONMENT_URL"), # Ensure URL is set
    )
    client = sdk.get_weaviate_client()
    ```

**4.3. Using Weaviate Client**
*   Once connected, you can use the standard Weaviate client functionalities.
    ```python
    vectordb_collection_name = "your_collection"
    weaviate_collection = client.collections.get(
        name=vectordb_collection_name,
    )
    # You can now use 'weaviate_collection' object to query, insert, etc.
    # For full functionality, refer to Weaviate's official documentation.
    ```

#### 5. Large Language Models (LLMs) Available

Craft AI provides access to various GenAI LLMs, each optimized for different use cases and performance characteristics.

| Model             | Context Window (API) | Description / Key Use Cases                                                                                                                                                                                                                                                                   |
| :---------------- | :------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **GPT-5.2**       | 400k tokens (272k In / 128k Out) | Advanced model for complex tasks: deep reasoning, programming, agent/tool orchestration, long document analysis, professional workflows.                                                                                                                                                   |
| **Mistral Large 3** | ≈256k tokens         | High-end model for enterprise applications: strong reasoning, efficient large document management, controlled inference costs. Well-suited for RAG systems and business assistants.                                                                                                                  |
| **Mistral Small** | ≈128k tokens         | Lighter model optimized for speed and cost: good reasoning and text generation for conversational assistants, high-volume applications, low-latency use cases.                                                                                                                                    |
| **GPT-5 mini**    | 400k tokens (272k In / 128k Out) | Lighter version of GPT-5 optimized for cost/performance: ideal for conversational assistants, large-scale applications, agent systems requiring low latency and cost.                                                                                                                |
| **Qwen3 235B**    | ≈128k tokens         | Large open-weights model: reasoning, mathematics, programming, strong multilingual capabilities. Often used for advanced agents or powerful, controllable systems.                                                                                                                             |
| **GPT-oss 120B**  | ≈128k tokens         | Open-weights model for sovereign or self-hosted deployments: good balance of power, cost, and infrastructure control. Suitable for internal assistants and enterprise RAG systems.                                                                                                               |
This document outlines the setup, usage, and key features of an MLOps platform, focusing on technical implementation and operational aspects.

---

### MLOps Platform Technical Guide

**1. Platform Overview**
The platform provides a managed infrastructure for MLOps workflows, encompassing data storage, computation (environments), and model deployment. It supports both a web-based User Interface (UI) and a Python Software Development Kit (SDK) for comprehensive interaction.

**2. Initial Setup & Prerequisites**

*   **Prerequisites:**
    *   Python 3.9 or higher.
    *   Google Chrome browser (recommended for UI).
*   **Access Methods:**
    *   **Web UI:** Accessed via a provided platform link in a compatible browser.
    *   **Python SDK:** For script-based interaction and command-line operations.
    *   *Note: Both methods are necessary for complete workflow management.*

**3. Project & Environment Creation (UI)**

*   **Project Creation:**
    1.  Log in to the platform UI.
    2.  On the main page, click "New Project" (top-right corner).
    3.  Configure the project:
        *   **Project name:** (User-defined)
        *   **Organization:** (Default)
        *   **Python version:** (Default)
        *   **Folders:** Set to `/` for initial platform access.
*   **Environment Creation:**
    1.  Navigate into the newly created project.
    2.  Click "New environment" (top-right corner).
    3.  Configure the environment:
        *   **Environment Name:** (User-defined)
        *   **Tag:** `Testing` (recommended for initial setup)
        *   **Cloud Provider:** `Scaleway` (example)
        *   **Machine:** `CPU - CPU Size 1` (example)
    4.  Environment creation typically takes approximately 5 minutes.

**4. Python SDK Initialization**

*   **Installation:**
    ```bash
    pip install craft-ai-sdk
    ```
*   **Authentication Token Retrieval:**
    1.  **MY_ENVIRONMENT_URL:** Found on the "Environments" page in the UI (this is not the browser URL).
    2.  **MY_ACCESS_TOKEN:** Located in the UI: Click your name (top-right) > "Parameters" > "SDK token" (generate if needed). This token is personal and confidential.
*   **SDK Initialization Script:**
    ```python
    from craft_ai_sdk import CraftAiSdk
    sdk = CraftAiSdk(
        environment_url="MY_ENVIRONMENT_URL", # Replace with your environment URL
        sdk_token="MY_ACCESS_TOKEN" # Replace with your access token
    )
    ```
*   **Credential Management (Recommended): `.env` File**
    *   **Install `python-dotenv`:**
        ```bash
        pip install python-dotenv
        ```
    *   **Create `.env` file:**
        ```
        # .env
        CRAFT_AI_ENVIRONMENT_URL=YOUR_ENVIRONMENT_URL
        CRAFT_AI_SDK_TOKEN=YOUR_ACCESS_TOKEN
        ```
    *   **Load credentials in script:**
        ```python
        # my-sdk-script.py
        import os
        from dotenv import load_dotenv
        from craft_ai_sdk import CraftAiSdk

        load_dotenv() # Loads variables from .env file

        sdk = CraftAiSdk(
            environment_url=os.getenv("CRAFT_AI_ENVIRONMENT_URL"),
            sdk_token=os.getenv("CRAFT_AI_SDK_TOKEN")
        )
        ```

**5. Environment Management & External Data Sources**

*   **Environment Definition:** An isolated infrastructure (cluster for computation, Data Store for storage) designed for efficient and scalable execution of pipelines.
*   **Key Objectives:** Simplify infrastructure management, automate resource use, enable large-scale deployments, facilitate environment sizing, and support SDLC best practices (experimentation, testing, production).
*   **Supported Providers:** AWS, GCP, S3NS, Scaleway.
*   **Environment Tags:** `Experimentation`, `Testing`, `Production` (currently for organizational purposes, future support for migration workflows and access control).
*   **Accessing External Data Sources:**
    *   **Purpose:** Connect to external databases or object storage without data transfer.
    *   **Method:** Define connection parameters using environment variables.
    *   **Environment Variable Declaration:**
        *   **Persistent (UI):** Navigate to `Environment settings` (via "..." on environment or `Settings` > `Environment` tab) > `Environment variables` tab. Define `Name`/`Value` pairs.
        *   **Programmatic (SDK):**
            ```python
            sdk.create_or_update_environment_variable("VARIABLE_NAME", "variable_value")
            ```
    *   **Loading in Code:** Use `python-dotenv` and `os.environ` to access variables (as shown in SDK initialization).
    *   **External Authorizations:** Whitelist the platform environment URL in your external data source's firewall/security settings if connection issues occur.
    *   **Example: Database Connection:**
        ```python
        # Declare variables via UI or SDK: DB_HOST, DB_ADMIN, DB_PASS, DB_NAME, DB_PORT
        import os
        from dotenv import load_dotenv
        load_dotenv()
        # ... retrieve DB_HOST, etc. via os.environ ...
        conn = create_db_connection(host=DB_HOST, user=DB_ADMIN, password=DB_PASS, database=DB_NAME, port=DB_PORT)
        # ... perform database operations ...
        conn.close()
        ```
    *   **Example: Fetch CSV from S3-compatible Bucket:**
        ```python
        # Declare variables via UI or SDK: SERVER_PUBLIC_KEY, SERVER_SECRET_KEY, REGION_NAME
        import os
        import pandas as pd
        from dotenv import load_dotenv
        load_dotenv()
        # ... retrieve SERVER_PUBLIC_KEY, etc. via os.environ ...
        client = configure_client(public_key=SERVER_PUBLIC_KEY, secret_key=SERVER_SECRET_KEY, region=REGION_NAME)
        buffer = get_object_from_bucket(client=client, bucket_name=bucket, key=key)
        dataframe = pd.read_csv(buffer)
        ```

**6. Resource Monitoring**

*   **Purpose:** Observe environment infrastructure health, identify resource over-utilization, and track resource evolution over time.
*   **UI Access:**
    *   Navigate to `Monitoring > Resource metrics`.
    *   Select an environment to view resource usage cards and graphs for individual workers and cumulative workers.
    *   Download displayed data in `.csv` format.
*   **SDK Access:**
    *   Retrieve resource metrics programmatically:
        ```python
        # Returns CSV data as bytes when csv=True
        resource_data_csv = sdk.get_resource_metrics(start_date="YYYY-MM-DD", end_date="YYYY-MM-DD", csv=True)
        ```

**7. CraftGPT Capabilities (AI/ML Specifics)**

*   **Core Functionality:** Provides advanced AI applications, including Retrieval-Augmented Generation (RAG) and conversational agents.
*   **RAG Applications:**
    *   Supports contextual RAG, agentic RAG (e.g., Legal Assistant, Search in Image), and web search integration.
    *   RAG data files are managed within the environment's Data Store under the "RAG" folder.
    *   RAG parameters (N_documents, score_threshold) can be configured via Data Store files.
*   **Supported Models:** Integrates various LLMs (e.g., Mistral, OpenAI, Gemma 3, Pixtral, GPT-4o).
*   **Customization:**
    *   Users can set custom `temperature` and `preprompt` values for applications.
    *   Conversation history is supported for RAG and text-only applications.
*   **Usage Monitoring:**
    *   Tracks unique users and token counts (per week, month, day).
    *   Monitoring data is stored in the "Usage Monitoring" folder at the root of the Data Store.
This guide outlines the process for creating and deploying pipelines with custom Docker configurations on the Craft AI Platform, focusing on establishing a reproducible and controlled environment for your machine learning or large language model (ML/LLM) workloads.

---

### Technical Guide: Custom Docker Pipelines

**Overview**
Custom Docker pipelines allow you to define a specific container environment for your pipeline's execution, providing full control over system and Python dependencies. This is particularly useful for complex ML/LLM models requiring specific configurations or non-standard libraries, ensuring consistency and reproducibility across environments.

**Prerequisites & Constraints**
*   **Docker Expertise:** This is an advanced feature and requires experience with Docker.
*   **Deployment Mode:** Only supported in `Elastic Deployment` mode; `low-latency` mode is not compatible.
*   **SDK & Docker Documentation:** Refer to the Craft AI SDK and official Docker documentation for detailed function and Dockerfile syntax.
*   **Code Size Limits:**
    *   Embedded code (from local folder/Git repo) must not exceed 5MB. For larger data, use the Data Store.
    *   Input size (except files) must not exceed 0.06 MB.

---

#### **Step 1: Prepare Your Dockerfile**

The Dockerfile defines the pipeline's execution environment. It should specify the base image, working directory, dependencies, and the entry point for your code.

**Key Dockerfile Directives:**

*   **Base Image:** Start with a suitable Python base image.
    *   `FROM python:3.9-slim`
*   **Working Directory (Mandatory):** The `/app` folder is the mandatory working directory.
    *   `ENV ROOT_DIR /app`
    *   `WORKDIR ${ROOT_DIR}`
*   **Install System Dependencies:** Use `apt-get` to install necessary system-level packages.
    *   `RUN apt-get install dependencies`
*   **Install Python Dependencies:** Use `pip` to install Python libraries.
    *   `RUN pip install dependencies`
*   **Copy Code:** Copy your repository's files into the Docker container.
    *   `COPY . .` (Copies the entire repo root into `/app`)
*   **Entrypoint:** Define the command that will be executed when the container starts, launching your Python script.
    *   `ENTRYPOINT ["python", "src/your_script.py"]`

**Example Dockerfile:**

```dockerfile
FROM python:3.9-slim

ENV ROOT_DIR /app
WORKDIR ${ROOT_DIR}

# Install system dependencies (e.g., specific build tools or libraries)
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    # Add other system dependencies here if needed
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies from a requirements.txt (recommended)
# COPY requirements.txt .
# RUN pip install --no-cache-dir -r requirements.txt
# Alternatively, install directly if only a few
RUN pip install --no-cache-dir pandas scikit-learn

# Copy your local repository content into the container
COPY . .

# Define the command to run your Python script
ENTRYPOINT ["python", "src/my_pipeline_script.py"]
```

---

#### **Step 2: Adapt Your Pipeline Python Code**

Your Python script needs to handle inputs received via command-line arguments and produce outputs by writing files to the `/app` directory with a specific prefix.

**Code Adaptation Requirements:**

1.  **Direct Function Call:** Call the main function of your pipeline directly within the script (e.g., in an `if __name__ == "__main__":` block).
2.  **Input Handling (`sys.argv`):**
    *   The script receives two command-line arguments, both serialized JSON strings.
    *   **`sys.argv[1]`**: Contains non-file inputs as a JSON object (key: input name, value: input value).
    *   **`sys.argv[2]`**: Contains file inputs as a JSON object (key: input name, value: object containing the file path, e.g., `{"path": "/app/input_file.txt"}`).
3.  **Output Handling:**
    *   Write output files to the `/app` folder.
    *   Prefix all output filenames with `output-`.
    *   **Note:** If returning a file via an endpoint, only one file can be returned directly.

**Example Python Pipeline Script (`src/my_pipeline_script.py`):**

```python
import json
import sys
import os

def my_function(number_input, file_input):
    """
    Example pipeline function that processes a number and a file.
    """
    print(f"Received number_input: {number_input}")

    file_contents = []
    if file_input and "path" in file_input:
        with open(file_input["path"], 'r') as f:
            file_contents = f.readlines()
        print(f"File contents: {file_contents}")

    # Your core pipeline logic here
    processed_result = [
        f"Processed number: {number_input * 2}",
        f"Lines in file: {len(file_contents)}"
    ]
    return processed_result

if __name__ == "__main__":
    # 1. Pre-processing: Parse Inputs
    parameters_inputs = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    files_inputs = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}

    # Extract specific inputs expected by my_function
    # Example for non-file input
    number_value = parameters_inputs.get("my_number_input", 0)
    # Example for file input
    file_object = files_inputs.get("my_file_input", {})

    # 2. Call your main pipeline function
    result = my_function(number_value, file_object)

    # 3. Post-processing: Write Outputs
    output_dir = '/app'
    os.makedirs(output_dir, exist_ok=True) # Ensure output directory exists

    # Write a variable output as JSON
    with open(os.path.join(output_dir, 'output-result_var.json'), 'w+') as f:
        json.dump({"result_data": result}, f)

    # Write a file output
    with open(os.path.join(output_dir, 'output-result_file.txt'), 'w') as f:
        f.write('\n'.join(f'* {item}' for item in result))

    print("Pipeline execution completed and outputs written.")
```

---

#### **Step 3: Define Pipeline Inputs and Outputs (SDK)**

Before creating the pipeline, define its expected inputs and outputs using the Craft AI SDK's `Input` and `Output` objects.

```python
from craft_ai_sdk import Input, Output

# Define inputs for your pipeline
input_number = Input(
    name="my_number_input",
    data_type="number",
    description="A number parameter for processing.",
    is_required=True,
)

input_file = Input(
    name="my_file_input",
    data_type="file",
    description="A file input for the pipeline.",
    is_required=False,
)

# Define outputs for your pipeline
output_variable = Output(
    name="result_data",
    data_type="string", # Or "json" if you want to handle it as such
    description="The processed variable output.",
)

output_file = Output(
    name="result_file",
    data_type="file",
    description="A file containing processed results.",
    default_value="", # Can provide a default content if needed
)
```

---

#### **Step 4: Create the Pipeline using the SDK**

Use the `sdk.create_pipeline()` function, specifying the `dockerfile_path` within the `container_config`. Note that you **do not** specify `function_path` or `function_name` as these are handled by the Dockerfile's `ENTRYPOINT`.

```python
import os
from craft_ai_sdk import CraftAiSdk, Input, Output

# Assuming sdk is initialized
# sdk = CraftAiSdk(sdk_token=os.getenv("CRAFT_AI_SDK_TOKEN"), environment_url=os.getenv("CRAFT_AI_ENVIRONMENT_URL"))

# Re-use Input/Output definitions from Step 3

custom_docker_pipeline = sdk.create_pipeline(
    pipeline_name="my-custom-docker-pipeline",
    description="A pipeline using a custom Dockerfile for environment control.",
    container_config={
        # Specify either 'local_folder' or 'repository_url' for your code context
        # If your Dockerfile is in the root of your local repo:
        "local_folder": "./", # Path to the folder containing your Dockerfile and code
        "dockerfile_path": "Dockerfile", # Path to your Dockerfile within 'local_folder' or Git repo
        # OR if using a Git repository:
        # "repository_url": "https://github.com/your-org/your-repo.git",
        # "repository_branch": "main",
        # "repository_deploy_key": "YOUR_PRIVATE_KEY_IF_NEEDED", # For private repos
        # "included_folders": ["src/", "models/", "Dockerfile", "requirements.txt"] # List specific folders/files to include
    },
    inputs=[input_number, input_file],
    outputs=[output_variable, output_file],
)

print(f"Pipeline '{custom_docker_pipeline.name}' created successfully.")
```

**Next Steps:**
After creation, your pipeline can be used and deployed like any other pipeline within the Craft AI Platform. Refer to the "Deploy a pipeline" documentation for deployment instructions.

---

#### **Optional: Integrating VectorDB (Weaviate)**

If your pipeline requires a Weaviate Vector Database:

1.  **Enable at Environment Creation:** A Weaviate database must be selected during the creation of your Craft AI environment. It cannot be added later.
2.  **Access in Code:** Use the SDK to obtain a Weaviate client instance within your pipeline's Python script.

```python
import os
from craft_ai_sdk import CraftAiSdk
from dotenv import load_dotenv

# Load environment variables (if running locally or outside platform environment that provides them)
load_dotenv()

# Initialize SDK (token and URL are automatically injected in platform pipelines)
# sdk = CraftAiSdk(
#     sdk_token=os.getenv("CRAFT_AI_SDK_TOKEN"),
#     environment_url=os.getenv("CRAFT_AI_ENVIRONMENT_URL"),
# )

# Get the Weaviate client
# If running within a platform pipeline, CRAFT_AI_SDK_TOKEN and CRAFT_AI_ENVIRONMENT_URL
# are available as environment variables.
sdk = CraftAiSdk(
    sdk_token=os.environ.get("CRAFT_AI_SDK_TOKEN"),
    environment_url=os.environ.get("CRAFT_AI_ENVIRONMENT_URL"),
)
client = sdk.get_weaviate_client()

# Use the Weaviate client (e.g., access a collection)
vectordb_collection_name = "your_collection_name"
weaviate_collection = client.collections.get(name=vectordb_collection_name)

# Perform operations with weaviate_collection...
```
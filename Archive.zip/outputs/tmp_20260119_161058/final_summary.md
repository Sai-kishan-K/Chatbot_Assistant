This guide summarizes key functionalities and recent updates for the Craft AI MLOps Platform, focusing on project management, Git integration, pipeline creation and execution tracking.

---

## Craft AI MLOps Platform: Technical Guide

### 1. Platform Overview & Recent Updates (Version 2.2.12)

The Craft AI MLOps Platform is currently at **version 2.2.12** (SDK 0.70.2, API 2026-01-13).

**Key Enhancements & Changes:**

*   **Core Platform:**
    *   Python 3.9 projects were automatically upgraded to 3.10.
    *   Supported Python versions updated (3.9 removed, 3.14 added) and CUDA versions updated.
    *   Improved error messages for failed datastore file uploads (e.g., file name length).
    *   Execution input/output containing NULL UTF8 characters can now be fetched.
    *   Deployment API calls now return `202` instead of `303` for validateStatus.
    *   An asynchronous Weaviate client function and its documentation (`get_weaviate_client`) have been added to the SDK.
*   **User & Administration:**
    *   Super-admins can create batches of users via CSV in the Back-Office and assign them to Organizations/Projects.
    *   A dedicated signup page and route for user registration are available.
    *   Private cloud accounts can now be managed at the organization level.
*   **Pipelines & Deployments:**
    *   `step_input_name` and `step_output_name` parameters from `InputSource` and `OutputDestination` objects have been removed; use `pipeline_input_name` and `pipeline_output_name` instead (**Breaking Change: Version 2.1.20**).
    *   Pipeline templates can now be used for deploying self-hosted Large Language Models (LLMs).
    *   Model templates can no longer be selected for CPU environments during deployment creation.
    *   Endpoint tokens can be provided/updated in deployment forms/sliders.
    *   Input default values can now be set in the console.
    *   Pipeline executions can now be nested (called within another pipeline).
    *   A new pipeline template selector (preview) is available in deployment creation.
    *   UI improvements for deployment pills, pipeline table, and input field size in deployment workflows.
    *   Error logging for low-latency mode corrected.
*   **Data Store:**
    *   Objects can be filtered by their folder path.
    *   "0 bytes" is displayed for empty files on the datastore page.
*   **UI/UX & Bug Fixes:**
    *   Numerous bug fixes and quality-of-life improvements across the platform, including fixes for "Git commit" filter, datastore pagination, pipeline log slider, execution link, and breadcrumbs.
    *   Display erroneous pipeline and deployment statuses in name tags.
    *   Input, output, and metrics are now distinct columns.
    *   `RESUMING` status replaces `STANDBY` for environments in `resuming step 2`.

### 2. Project Management

A **Project** serves as a logical grouping for environments and users, allowing for structured organization and an overview of all associated environments.

**2.1. Project Creation**
To create a project:
1.  Navigate to the main page.
2.  Click the "New project" button (top right).
3.  Fill out the form:
    *   **General:** Project name, organization, default Python version.
    *   **Git Connection:** Configure integration with a Git repository.
    *   **Libraries & Packages:** Specify project-level dependencies.

**2.2. Git Connection**
Integrating your project with a Git repository is recommended for versioning, code sharing, and production best practices.

**2.2.1. Generate SSH Keys**
You need an RSA-encrypted SSH key pair (private/public) to secure communication between the Platform and your Git repository.

*   **Linux/MacOS:**
    ```bash
    ssh-keygen -m PEM -t rsa -b 4096 -f my-key-filename -q -N "" -C ""
    ```
    This generates `my-key-filename` (private) and `my-key-filename.pub` (public).
*   **Windows:**
    1.  Install OpenSSH (Settings > Apps & features > Optional features).
    2.  Open Command Prompt as Administrator.
    3.  Type `ssh-keygen`.
    4.  Choose a filename (default: `C:\Users\your_username\.ssh\id_rsa`).
    5.  Optionally, set a passphrase (leave blank for no passphrase).
    6.  The private key is in `id_rsa`, public in `id_rsa.pub`.

    **Warning:** Never share your private key. Do not store it in the Platform's data store.

**2.2.2. Add Public Key to Repository**
Add the generated public key (`*.pub` content) to your Git repository's settings as a deploy key. Read-only access is typically sufficient.

*   **GitHub:** Repository > Settings > Deploy Keys > Add deploy key.
*   **GitLab:** Repository > Settings > Repository > Expand Deploy keys > Add key.

**2.2.3. Integrate Git with Platform**
The private key is used to allow the Platform to access the repository.

*   **Project Settings (Default):**
    1.  Go to your project's settings page.
    2.  Provide the following:
        *   **Repository URL:** SSH URL (e.g., `git@github.com:my-account/my-repo.git`).
        *   **Deploy key:** Copy/paste the entire private key content, including `-----BEGIN RSA PRIVATE KEY-----` and `-----END RSA PRIVATE KEY-----` tags.
        *   **Default branch:** The Git branch to use by default for this project (can be overridden).
    This configuration will apply to all pipelines created within the project by default.

*   **Pipeline Creation (SDK - Overrides Project Settings):**
    You can specify Git details during pipeline creation using the `container_config` parameter in `sdk.create_pipeline()`.
    Example:
    ```python
    import craft_ai_sdk as sdk

    with open('keys/my-key-filename', 'r') as file:
        private_key_value = file.read().rstrip()

    sdk.create_pipeline(
        function_path="src/my-source-code.py",
        function_name="my-function-name",
        pipeline_name="my-pipeline-name",
        container_config={
            "repository_url": "git@github.com:my-account/my-git-repo.git",
            "repository_deploy_key": private_key_value,
            "repository_branch": "main"
        }
    )
    ```

**2.3. Libraries and Packages**
Manage dependencies using a `requirements.txt` file.

*   **Project-level:** Reference a `requirements.txt` file in Project settings. All pipelines in the project will inherit these dependencies.
*   **Pipeline-level:** Override project-level dependencies by specifying a `requirements.txt` file during pipeline creation.
*   **Format:** `package==xx.xx.xx` (e.g., `craft_ai_sdk==xx.xx.xx`).
*   Additional APK or PAT packages can also be listed.

### 3. Pipeline Management

A **pipeline** is a Python function with defined inputs and outputs, storing its code either locally or in a Git repository. Pipelines are environment-specific.

**3.1. Pipeline Creation (SDK)**
Pipelines are created using the Python SDK.

*   **Code Structure:**
    ```
    ├── requirements.txt
    └── src/
        └── my_entry_function_pipeline.py
    ```
    `my_entry_function_pipeline.py`:
    ```python
    import numpy as np

    def entryPipeline(dataX_input, dataY_input):
        # Code
        return result_output
    ```
*   **Input/Output Objects:** Define pipeline parameters using `craft_ai_sdk.Input` and `craft_ai_sdk.Output`.
    ```python
    from craft_ai_sdk import Input, Output

    input1 = Input(name="input1", data_type="string", description="...", is_required=True)
    input2 = Input(name="input2", data_type="file", description="...")
    output1 = Output(name="prediction", data_type="file", default_value="default content")

    pipeline = sdk.create_pipeline(
        function_path="src/foo.py",
        function_name="my_function",
        description="Apply the model to the sea",
        container_config={"local_folder": "/users/craftai/"}, # Or Git config
        inputs_list=[input1, input2],
        outputs_list=[output1],
    )
    ```
*   **Constraints:**
    *   Embedded code (folder/Git repository) must not exceed 5MB. For larger data, use the Data Store.
    *   Inputs must not exceed 0.06 MB (except for files).

**3.2. Pipeline Management (Platform UI)**
Access pipelines from the `Project` screen via the "Pipeline" menu or by clicking the "PIPELINES" count on an environment card.

*   **Information Panel:** Clicking a pipeline name or the "..." menu displays a side-panel with:
    *   **Pipeline information:** Name, description, downloadable source code (.tgz), `requirements.txt` if specified, environment, creation details, associated deployment link, last execution status and timestamp (with "Explore" button to logs).
    *   **Input/Output:** Details (name, type, default value) for each input and output.
    *   **Logs:** Displays the last 200 lines of logs, with options to refresh or download the full log file.
*   **Actions:**
    *   **Delete:** Pipelines can be deleted individually (from "..." menu or info panel) or in bulk (checkboxes on pipeline page). Deleting a pipeline also removes associated executions, logs, and deployments.

### 4. Execution Tracking & Comparison

Once pipelines are deployed and run, their executions can be monitored and analyzed.

**4.1. Execution Tracking**
1.  From the `Project` screen, click the "Executions" menu.
2.  Select "Execution Tracking".
3.  Choose an environment from the dropdown, then select a specific pipeline run or deployment.
4.  The left menu will list associated executions. Select one to view its details on the right, categorized into tabs:
    *   **General:** Read-only information including Run ID, Status (Success/Failed/Error), Pipeline name, Deployment name, Creator, Execution rule (Endpoint/Periodic/Run), Environment, Computing Size, Start/End times (UTC), and Duration.
    *   **Input/Output:** A list of all defined inputs and outputs for the execution, including their Name, Type, Size, Source, and Value.
    *   **Metrics:** (Tab exists, but details are not provided in the source text).
    *   **Logs:** Displays the last 200 lines of console output (logging messages, errors, `print` statements). You can refresh and download the complete log file.

**4.2. Execution Comparison**
Use the "Execution Comparison" panel to compare multiple executions side-by-side. This feature aids in analyzing differences in results, execution times, and other parameters, useful for pipeline evolution and optimization.
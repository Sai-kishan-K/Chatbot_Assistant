This document serves as a technical guide for setting up and managing ML projects, environments, data, and pipelines on the Platform.

---

## 1. Projects: Organizing Your Workflows

Projects are human-centric "mind views" for logically grouping environments and managing user access. They do not directly influence underlying components but provide an overview.

### 1.1. Project Creation
1.  **Navigate:** From the main page, click **"New project"** in the top right corner.
2.  **Fill Form:**
    *   **General:** Define **Project name**, **organization**, and default **Python version**.
    *   **Git connection:** Configure integration with a Git repository for version control (refer to "Connect to Git" documentation for full steps).
    *   **Libraries & Packages:**
        *   **Python packages:** Specify project-wide Python dependencies using a **`requirements.txt`** file.
            *   **Format:** `package_name==xx.xx.xx` (e.g., `craft_ai_sdk==xx.xx.xx`)
            *   This file is inherited by pipelines within the project but can be overridden at pipeline creation.
        *   **APK/PAT packages:** List additional application packages by typing the name and pressing **`+`** or **`Enter`**. Remove by clicking the **`x`**.

### 1.2. User Management
*   Assign users access to **all projects** or restrict them to **testing/experimenting** only.

---

## 2. Environments: Compute & Storage Infrastructure

An environment is the core infrastructure (cluster + Data store) for running computations and storing data within a project.

### 2.1. Environment Creation
1.  **Navigate:** Within a project, click **"New environment"** in the top right corner.
2.  **Fill Form:**
    *   **General:**
        *   **Environment name:** 3-20 characters, no special characters.
        *   **Tag:** Assign **Experimentation, Testing,** or **Production**.
    *   **Computing resources:**
        *   **Cloud provider:** Select **AWS, GCP, S3NS,** or **Scaleway**.
        *   **Zone:** Automatically selected based on the provider (e.g., France for GCP/Scaleway).
        *   **Machine:** Choose **CPU** or **GPU** and select a machine **size**. Refer to the Platform's default configuration table for hardware specifications (CPU/RAM/Disk/VRAM).
        *   **Workers:** Specify the number of workers for task parallelization (e.g., 2, 4, 6...).
    *   **Storage resources:**
        *   **Data store provider:** Automatically populated with the selected cloud provider.
        *   **Vector database provider:** Option to add a **Weaviate** Vector DB for LLM functionalities.
    *   **Runtime Planner:** Configure environment shutdown/restart schedules to optimize costs and resources.
        *   **Operational Days:** Toggle days for environment operation (e.g., deselect weekends).
        *   **Resume Time (UTC):** Set the time for environment restart.
        *   **Standby Time (UTC):** Set the time for environment shutdown.

### 2.2. Environment Management
Once created, manage an environment via its settings:
1.  **Access Settings:** Click the settings icon or the "..." menu on the environment card.
2.  **State Control:**
    *   **Put operational/put on standby:** Toggle the environment's active state. Standby mode allows read-only access but prevents execution.
3.  **Delete:** Remove the environment and all associated content.
4.  **Settings Page:**
    *   **Overview Tab:** View current environment details (name, type, status, URL, IP, creation date).
        *   **Resources:** Cloud provider and Machine size are displayed but **cannot be modified**.
        *   **Runtime Planner:** **Can be modified** (Operational Days, Resume Time, Standby Time).
    *   **Environment Variables Tab:** Add, view, and manage **key/value** environment variables for the selected environment.

---

## 3. Data Store: Managing Internal and External Data

The Data Store provides cloud storage for files within each environment and connectivity to external sources.

### 3.1. Internal Data Store (Cloud Bucket)
*   **Purpose:** Store input files, generated results, and other useful data.
*   **Access:** Click the **"Data store"** tab at the top of the screen.
*   **Navigation:** Browse files and folders using a tree-like structure.
*   **Actions:**
    *   **Upload:** Manually add files to the Data store.
    *   **Download:** Retrieve files from the Data store.
    *   **Create a new folder:** Add a new folder in the current directory.
    *   **Copy a file or folder:** Select an item (checkbox or "...") and use **"Copy to"** to choose a destination (can create new folders).
    *   **Delete:** Remove files/folders (use with caution, as mandatory files are not detected).
    *   **Rename:** Change the name of files or folders.

### 3.2. Vector Database Integration
*   The Platform supports **Weaviate** as a Vector Database, co-created with your environment, for RAG functionalities in LLM applications.

### 3.3. Accessing External Data Sources
Connect to external databases or cloud buckets by setting environment variables.

#### 3.3.1. Setup Environment Variables
Variables can be defined with different persistence:
*   **Persistent (Environment Settings):**
    1.  Navigate to **Environment Settings** (either via the "..." menu on the environment or the Project Settings -> Environment tab).
    2.  Go to the **"Environment variables"** tab.
    3.  Add **`Name`** and **`Value`** pairs for each variable.
*   **Session-based (SDK in Code):**
    ```python
    sdk.create_or_update_environment_variable("USERNAME", "username_db_1")
    ```
    Then, load them in your script:
    ```python
    import os
    import dotenv
    dotenv.load_dotenv()
    username = os.environ["USERNAME"]
    ```

#### 3.3.2. External Authorization
*   If connections fail, **whitelist your environment URL** in your external data source's firewall or security settings. The environment URL is found on the Project screen.

#### 3.3.3. Connection Examples
*   **Connect to an External Database:**
    1.  Declare variables via SDK or Environment Settings (e.g., `DB_HOST`, `DB_ADMIN`, `DB_PASS`, `DB_NAME`, `DB_PORT`).
    2.  Load variables in code and use them to establish a connection.
    ```python
    # Example snippet (after loading variables)
    conn = create_db_connection(host=DB_HOST, user=DB_ADMIN, password=DB_PASS, database=DB_NAME, port=DB_PORT)
    # ... use conn to fetch data ...
    conn.close()
    ```
*   **Fetch a CSV file from a Distant Bucket:**
    1.  Declare variables via SDK or Environment Settings (e.g., `SERVER_PUBLIC_KEY`, `SERVER_SECRET_KEY`, `REGION_NAME`).
    2.  Load variables in code and use them to configure a client and retrieve the object.
    ```python
    # Example snippet (after loading variables)
    client = configure_client(public_key=SERVER_PUBLIC_KEY, secret_key=SERVER_SECRET_KEY, region=REGION_NAME)
    buffer = get_object_from_bucket(client=client, bucket_name=bucket, key=key)
    dataframe = pd.read_csv(buffer)
    ```

---

## 4. Pipelines: Orchestrating Machine Learning Workflows

Pipelines define and execute end-to-end machine learning workflows, specified by inputs, code, and outputs. They run on Kubernetes pods, ensuring isolation and scalability.

### 4.1. Key Capabilities
*   **Orchestration:** Manage complex ML workflows from data preparation to deployment.
*   **Collaboration:** Track and view pipeline definitions collaboratively.
*   **Deployment:** Easily deploy models into production via endpoints, schedulers, etc.
*   **Scalability:** Enable large-scale execution of Python code.
*   **Efficiency:** Ensure optimal use of compute resources.

### 4.2. Pipeline Structure (Common Examples)

#### 4.2.1. Training Pipeline
1.  **Data preparation and preprocessing:** Collect, clean, and transform raw data (e.g., filtering, normalization, encoding).
2.  **Model training:** Train an ML model on the prepared dataset (e.g., model selection, hyperparameter tuning, optimization).
3.  **Model evaluation:** Assess model performance on new data (e.g., train/test split, performance metrics, baseline comparison).

#### 4.2.2. Inference Pipeline
1.  **Model loading:** Load a trained ML model from storage.
2.  **Data preparation:** Clean and transform incoming data for the model.
3.  **Inference:** Use the loaded model to make predictions on the prepared data.
This document outlines the technical capabilities and operational procedures for leveraging the Craft AI platform, encompassing MLOps workflows and secure LLM agent deployments.

## 1. Introduction to Craft AI

Craft AI is a platform designed for developing and deploying AI applications at scale. It supports:
*   Training and deploying Machine Learning (ML) models.
*   Creating secure AI agents powered by Large Language Models (LLMs), integrated with enterprise data.
*   Hosting applications on various cloud providers (AWS, GCP, Scaleway, OVHCloud, S3NS, Outscale).
*   Full monitoring, cost/carbon impact management, and compliance with European regulations (GDPR, AI Act).
*   Implementing MLOps best practices across the entire model lifecycle.

## 2. Core Concepts

*   **Projects:** Logical groupings for environments, users, and pipelines. Defines default Python versions, Git connections, and libraries.
*   **Environments:** The core infrastructure for data storage and computation (fully managed Kubernetes cluster + Data store). Isolated and independent.
    *   **Tags:** Experimentation, Testing, Production (for organizational clarity and future access control).
    *   **Components:** Cluster (compute) and Data Store (storage).
*   **Data Store:** Cloud object storage (bucket) associated with each environment for storing files, pipeline inputs/outputs, and metrics.
    *   **VectorDB:** Weaviate database can be integrated with environments for LLM RAG capabilities.
*   **Pipelines:** Python-based ML workflows defined by inputs, code, and outputs. Executed on Kubernetes pods.
*   **Executions:** Instances of a pipeline or deployment run, with trackable status, inputs, outputs, metrics, and logs.
*   **Deployments:** Automated, repeatable triggers for pipeline executions (via API endpoint or periodic scheduler).

## 3. Getting Started & Setup

### 3.1. Prerequisites
*   Python 3.9+
*   Google Chrome (recommended for UI)
*   `craft-ai-sdk` Python package (`pip install craft-ai-sdk`)

### 3.2. Platform Access (UI & SDK)
1.  **UI Access:** Navigate to the platform URL.
    *   **First Connection:** Register via invitation link, set password (MFA optional, requiring Google Authenticator/Auth0 Guardian).
    *   **Admin Space:** Accessible only to administrators for managing assistants and users.
2.  **SDK Initialization:**
    *   Obtain `MY_ENVIRONMENT_URL` (from Environment page) and `MY_ACCESS_TOKEN` (from User Parameters > SDK Token).
    *   Initialize SDK: `sdk = CraftAiSdk(environment_url="MY_ENVIRONMENT_URL", sdk_token="MY_ACCESS_TOKEN")`
    *   **Best Practice:** Use a `.env` file with `python-dotenv` for credentials:
        ```python
        import os; from dotenv import load_dotenv; from craft_ai_sdk import CraftAiSdk
        load_dotenv()
        sdk = CraftAiSdk(environment_url=os.getenv("CRAFT_AI_ENVIRONMENT_URL"), sdk_token=os.getenv("CRAFT_AI_ACCESS_TOKEN"))
        ```

### 3.3. Project & Environment Creation (UI)
1.  **Create Project:** From the main page, click "New Project". Provide a name, select organization, Python version, and default local folder (e.g., `/`).
2.  **Create Environment:** Inside the project, click "New environment".
    *   **General:** Environment Name (3-20 chars, no special chars), Tag (Experimentation, Testing, Production).
    *   **Computing Resources:** Cloud Provider (AWS, GCP, S3NS, Scaleway), Zone (auto-selected), Machine (CPU/GPU, specific size), Workers (2-10).
    *   **Storage Resources:** Data Store Provider (auto-filled), Vector Database Provider (Weaviate, optional, selected at creation).
    *   **Runtime Planner:** Define operational days, resume time (UTC), and standby time (UTC) to manage resource usage and costs.

## 4. Project Management

### 4.1. Git Repository Integration
*   **Purpose:** Versioning, code sharing, production best practice.
*   **SSH Key Generation:** Generate an RSA-encrypted SSH key pair (private/public) on Linux/MacOS or Windows.
    *   `ssh-keygen -m PEM -t rsa -b 4096 -f my-key-filename -q -N "" -C ""`
*   **Add Public Key to Repository:** Add `my-key-filename.pub` content as a Deploy Key in GitHub/GitLab settings (without write access).
*   **Use in Platform:**
    *   **Project-wide:** In Project Settings, provide Repository URL (SSH format), Deploy Key (private key content with BEGIN/END tags), and Default Branch. Pipelines created will default to this repository.
    *   **Pipeline-specific (SDK):** Override project settings by providing `repository_url`, `repository_deploy_key`, and `repository_branch` in the `container_config` during `sdk.create_pipeline()`.

### 4.2. Libraries & Packages
*   Define project-level Python dependencies in a `requirements.txt` file (e.g., `craft_ai_sdk==xx.xx.xx`).
*   List additional APK or PAT packages in Project Settings.
*   These settings are inherited by pipelines; can be overridden during pipeline creation.

## 5. Environment Management

### 5.1. Operations
*   **Access Settings:** Modify environment configurations.
*   **Put Operational/Standby:** Manually control environment state. Standby allows read-only access but disables computation.
*   **Delete:** Remove environment and all associated content (pipelines, executions).

### 5.2. Environment Variables
*   **Define persistent variables:** In `Environment Settings` (UI) via Name/Value pairs.
*   **Define session-specific variables (SDK):** `sdk.create_or_update_environment_variable("VAR_NAME", "var_value")`. Load with `dotenv.load_dotenv()`.

### 5.3. Resource Monitoring
*   Access `Monitoring > Resource metrics` to view CPU, GPU, and RAM usage per worker over time.
*   Download data in `.csv` format.
*   SDK function: `sdk.get_resource_metrics(start_date, end_date, csv=True)`.

## 6. Data Management

### 6.1. Internal Data Store
*   **Access:** Via `Data store` tab in UI, browse tree-like structure.
*   **Operations:** Upload, Download, Create Folder, Copy, Delete, Rename files/folders.
*   **SDK:** `sdk.upload_data_store_object()`, `sdk.download_data_store_object()`.

### 6.2. External Data Sources
*   Connect to external databases or buckets by configuring environment variables (e.g., `DB_HOST`, `SERVER_PUBLIC_KEY`) in Environment Settings or via SDK.
*   Whitelist your environment URL in external data source settings.
*   Example code provided for connecting to a database and fetching a CSV from a distant bucket.

### 6.3. VectorDB (Weaviate)
*   **Creation:** Select Weaviate as Vector Database Provider during Environment creation.
*   **Access (SDK):**
    ```python
    from craft_ai_sdk import CraftAiSdk
    sdk = CraftAiSdk(sdk_token=..., environment_url=...)
    client = sdk.get_weaviate_client()
    collection = client.collections.get(name="your_collection")
    ```

## 7. Pipeline Development & Deployment

### 7.1. Pipeline Creation
*   **Definition:** Python function with inputs and outputs.
*   **Inputs/Outputs (SDK `Input`/`Output` objects):**
    *   `Input(name="param_name", data_type="string|number|boolean|json|array|file", is_required=True, description="...")`
    *   `Output(name="result_name", data_type="string|number|boolean|json|array|file", default_value="...")`
    *   Input/Output names must match function arguments/dictionary keys respectively.
    *   File inputs/outputs have size limits (0.06 MB for non-files, 5MB for embedded code). Use Data Store for larger data.
*   **SDK Command:**
    ```python
    sdk.create_pipeline(
        pipeline_name="my-pipeline",
        function_path="src/my_script.py", # Path relative to local_folder/git_repo
        function_name="my_function",
        description="...",
        inputs_list=[input1, input2],
        outputs_list=[output1],
        container_config={"local_folder": "src/"} # or Git repo config
    )
    ```
*   **Custom Docker Pipelines (Advanced):**
    *   **Restriction:** Only supported with `Elastic` Deployment mode.
    *   **Dockerfile:** Must use `FROM python:3.9-slim`, `WORKDIR /app`, and specify system/Python dependencies and `ENTRYPOINT ["python", "src/your_script.py"]`.
    *   **Pipeline Code:**
        *   Function called directly in `if __name__ == "__main__":`.
        *   Inputs received via `sys.argv[1]` (JSON for non-files) and `sys.argv[2]` (JSON for file paths).
        *   Outputs written to `/app/output-*.json` or `/app/output-*.txt`.
    *   **SDK Creation:** Use `dockerfile_path` in `container_config`; `function_path` and `function_name` are not required.

### 7.2. Pipeline Management (UI)
*   **Access:** `Pipelines` tab or directly from an Environment card.
*   **View Information:** Name, description, source code, requirements.txt, environment, creator, creation date, deployment, last execution status/logs.
*   **Actions:** Delete (single or multiple pipelines, deletes associated executions and deployments).

### 7.3. Pipeline Deployment
*   **Access:** From Pipelines page, select pipeline, click `Deploy`.
*   **Execution Modes:**
    *   **Low latency:** Pipeline always active, faster execution.
    *   **Elastic:** Enters standby when not in use, conserves resources.
*   **Trigger Conditions:**
    *   **Endpoint:** API call trigger. Provides a URL for external calls.
    *   **Periodic:** Scheduled execution using CRON configuration.
*   **Execution Management (Low Latency):**
    *   **Queue:** FIFO (First In First Out) for tasks. Retries failed tasks.
    *   **Parallel:** Specify number of parallel executions.
        *   **Recommendation:** Use `async def` for Python function for better compatibility with parallel execution.
        *   **Warnings:** Potential mixed logs, shared memory concurrency issues, ensure thread safety.
    *   **RAM Request:** Allocate RAM. Do not exceed total environment RAM.
        *   **Strategy:** Big processes (training) in `Queue` mode, smaller (inference) in `Parallel` mode.
*   **Input and Output Mapping:** Map pipeline inputs/outputs to endpoint parameters or constant values (for scheduled deployments, inputs are not available).
*   **Self-hosted LLM Deployment (Templates):**
    *   **Access:** From Deployment creation screen, select "New from Template".
    *   **Selection:** Choose model provider, model (e.g., Mistral Large 3), and quantization level (16bit, 8bit, 4bit).
        *   **Note:** Requires GPU environment with sufficient VRAM. Oversized models will fail.
    *   **Configuration (via deployment inputs/outputs):**
        *   `Messages`: List of messages in OpenAI chat format (`role`, `content`). Required.
        *   `Temperature`: Controls randomness (0.0-1.0). Map to constant or endpoint input. Null for default.
        *   `System Prompt`: Optional initial `system` message. Map to constant or endpoint input (not recommended to avoid conflicts).

## 8. Monitoring & Troubleshooting

### 8.1. Executions Tracking (UI)
*   **Access:** `Executions > Execution Tracking`.
*   **Selection:** Choose environment, then pipeline run or deployment.
*   **Details (4 tabs):**
    *   **General:** ID, Status (Success/Failed/Error), Pipeline/Deployment, Creator, Rule, Environment, Computing Size, Start/End/Duration.
    *   **Input/Output:** Name, Type, Size, Source, Value for all defined I/O.
    *   **Metrics:** Simple metrics (table), list metrics (graphs over epochs/steps).
    *   **Logs:** Last 200 lines, refresh, download full logs.
*   **SDK Access:** `sdk.get_pipeline_execution()`, `sdk.get_pipeline_execution_input()`, `sdk.get_pipeline_execution_output()`, `sdk.get_metrics()`, `sdk.get_list_metrics()`, `sdk.get_pipeline_execution_logs()`.

### 8.2. Executions Comparison (UI)
*   **Access:** `Executions > Execution Comparison`.
*   **Functionality:** Compare multiple executions side-by-side using tables and graphs.
*   **Configuration:** Select `meta-data`, `inputs`, `simple metrics`, `list metrics` columns. Filter by pipeline name. Sort by metric value.
*   **Visualize Tab:** Graphically compare list metrics across selected executions.

### 8.3. Pipeline Metrics
*   **Record (SDK):**
    *   `sdk.record_metric_value(name="accuracy", value=0.1409)` (single numeric value).
    *   `sdk.record_list_metric_values(name="loss_list", values=[1.4, 1.2])` (list of numeric values).
    *   **Note:** Use within pipeline code. Single metrics with identical names overwrite; list metrics append. List metrics are limited to 50,000 values.
*   **Monitor (UI):** `Monitoring > Pipeline metrics` shows evolution of single metrics over time for selected deployments.

### 8.4. User Interaction (Craft AI Application)
*   **Assistants:** Select an assistant, choose a model, type messages (Shift+Enter for new line), attach files (.pdf, .txt, .md, .docx, .xls, .csv), send messages, regenerate responses, provide feedback (thumbs up/down).
*   **Assistant Creation:** Define name, icon, objective, instructions (role, tone, rules, format), conversation starters. Pin to sidebar for quick access.
*   **Advanced Features:**
    *   **RAG Source Display:** View source documents and citations for RAG-generated responses.
    *   **Prompt Shortcuts:** Create `/<keyword>` shortcuts to insert predefined prompts in chat.
*   **Troubleshooting:** Contact administrator for forgotten passwords or "environment in standby" errors.

## 9. Administration

*   **Access:** Click button bottom-left of screen.
*   **User Management:** Invite users (individual emails or CSV batch upload), assign roles (admin/basic), set accounts inactive, delete accounts. Reset user passwords (temporary, must be changed by user securely).
*   **Assistant Management:**
    *   **Advanced Creation:** Connect assistants to pre-deployed AI Studio pipelines.
    *   **Visibility:** Mark assistants as "Featured" (pinned) or "Visible" (in explorer).
    *   **Default Assistant:** Configure instance-wide default assistant with specific instructions.
*   **AI Studio Configuration (via Data Store):**
    *   **RAG Document Addition:** Upload documents to the `RAG` folder in the environment Data Store.
    *   **Web Agent Whitelisting:** Upload `websearch-allowlist.txt` to the `craftgpt-config` folder with allowed URLs (one per line).